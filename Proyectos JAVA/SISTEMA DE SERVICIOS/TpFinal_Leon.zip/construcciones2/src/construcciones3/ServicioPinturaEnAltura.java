package construcciones3;

class ServicioPinturaEnAltura extends ServicioPintura {
    private int piso;
    private double costoSeguro;
    private double costoAlquilerAndamios;

    public ServicioPinturaEnAltura(int codigoServicio, int dniCliente, int numeroEspecialista, String tipoServicio, String direccion, double superficie, double costoMetroCuadrado, int piso, double costoSeguro, double costoAlquilerAndamios) {
        super(codigoServicio, dniCliente, numeroEspecialista, tipoServicio, direccion, superficie, costoMetroCuadrado);
        this.piso = piso;
        this.costoSeguro = costoSeguro;
        this.costoAlquilerAndamios = costoAlquilerAndamios;
    }

    @Override
    public double calcularImporteTotal() {
        double importe = super.calcularImporteTotal();
        if (piso > 5) {
            importe += costoAlquilerAndamios * 1.2;
        } else {
            importe += costoAlquilerAndamios;
        }
        importe += costoSeguro;
        return importe;
    }
}
