package construcciones3;

class Especialista {
    private int numeroEspecialista;
    private String nombre;
    private String telefono;
    private String servicioEspecializado;

    public Especialista(int numeroEspecialista, String nombre, String telefono, String servicioEspecializado) {
        this.numeroEspecialista = numeroEspecialista;
        this.nombre = nombre;
        this.telefono = telefono;
        this.servicioEspecializado = servicioEspecializado;
    }

    public int getNumeroEspecialista() {
        return numeroEspecialista;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getServicioEspecializado() {
        return servicioEspecializado;
    }
}
