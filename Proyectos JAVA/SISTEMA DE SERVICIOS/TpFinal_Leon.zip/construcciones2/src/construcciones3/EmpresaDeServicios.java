package construcciones3;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmpresaDeServicios {
	    private Map<Integer, Especialista> especialistas;
	    private Map<Integer, Cliente> clientes;
	    private Map<Integer, Servicio> servicios;
	    private Map<Integer, Double> serviciosFinalizados;
	    private int codigoServicioActual;
	    private Map<String, Double> facturacionTotalPorTipo;

	    public EmpresaDeServicios() {
	        especialistas = new HashMap<>();
	        clientes = new HashMap<>();
	        servicios = new HashMap<>();
	        serviciosFinalizados = new HashMap<>();
	        facturacionTotalPorTipo = new HashMap<>();
	        codigoServicioActual = 1;
	    }

	    public void registrarEspecialista(int numeroEspecialista, String nombre, String telefono, String servicioEspecializado) throws RuntimeException {
	        if (especialistas.containsKey(numeroEspecialista)) {
	            throw new RuntimeException("El n�mero de especialista ya est� registrado.");
	        }
	        if (!servicioEspecializado.equals("Pintura") &&
	                !servicioEspecializado.equals("PinturaEnAltura") &&
	                !servicioEspecializado.equals("Electricidad") &&
	                !servicioEspecializado.equals("GasistaInstalacion") &&
	                !servicioEspecializado.equals("GasistaRevision")) {
	            throw new RuntimeException("El servicio especializado no es v�lido.");
	        }

	        Especialista especialista = new Especialista(numeroEspecialista, nombre, telefono, servicioEspecializado);
	        especialistas.put(numeroEspecialista, especialista);
	    }

	    public void registrarCliente(int dni, String nombre, String numeroContacto) throws RuntimeException {
	        if (clientes.containsKey(dni)) {
	            throw new RuntimeException("El cliente ya est� registrado.");
	        }

	        Cliente cliente = new Cliente(dni, nombre, numeroContacto);
	        clientes.put(dni, cliente);
	    }
	    //servicios
	    public int solicitarServicioElectricidad(int dniCliente, int numeroEspecialista, String direccion, int horasTrabajo, double valorHora) throws RuntimeException {
	        // Verificar si el cliente y el especialista existen
	        if (!clientes.containsKey(dniCliente)) {
	            throw new RuntimeException("El cliente no est� registrado.");
	        }

	        if (!especialistas.containsKey(numeroEspecialista)) {
	            throw new RuntimeException("El n�mero de especialista no est� registrado.");
	        }
	     // Obtener el especialista
	        Especialista especialista = especialistas.get(numeroEspecialista);

	        // Verificar si el especialista se especializa en Electricidad
	        if (!especialista.getServicioEspecializado().equals("Electricidad")) {
	            throw new RuntimeException("El especialista no se especializa en Electricidad.");
	        }

	        // Validar los datos de electricidad
	        if (valorHora <= 0 || horasTrabajo <= 0) {
	            throw new RuntimeException("Los datos de electricidad deben ser mayores a 0.");
	        }

	        // Crear el servicio de electricidad
	        ServicioElectricidad servicioElectricidad = new ServicioElectricidad(codigoServicioActual, dniCliente, numeroEspecialista, "Electricidad", direccion, horasTrabajo, valorHora);
	        servicios.put(codigoServicioActual, servicioElectricidad);
	        codigoServicioActual++;

	        return servicioElectricidad.getCodigoServicio();
	    }
	    public int solicitarServicioPintura(int dniCliente, int numeroEspecialista, String direccion, double metrosCuadrados, double precioPorMetroCuadrado) throws RuntimeException {
	        // Verificar si el cliente y el especialista existen
	        if (!clientes.containsKey(dniCliente)) {
	            throw new RuntimeException("El cliente no est� registrado.");
	        }

	        if (!especialistas.containsKey(numeroEspecialista)) {
	            throw new RuntimeException("El n�mero de especialista no est� registrado.");
	        }

	        // Obtener el especialista
	        Especialista especialista = especialistas.get(numeroEspecialista);

	        // Verificar si el especialista se especializa en Pintura
	        if (!especialista.getServicioEspecializado().equals("Pintura")) {
	            throw new RuntimeException("El especialista no se especializa en Pintura.");
	        }

	        // Validar los datos de pintura
	        if (metrosCuadrados <= 0 || precioPorMetroCuadrado <= 0) {
	            throw new RuntimeException("Los datos de pintura deben ser mayores a 0.");
	        }

	        // Crear el servicio de pintura
	        ServicioPintura servicioPintura = new ServicioPintura(codigoServicioActual, dniCliente, numeroEspecialista, "Pintura", direccion, metrosCuadrados, precioPorMetroCuadrado);
	        servicios.put(codigoServicioActual, servicioPintura);
	        codigoServicioActual++;

	        return servicioPintura.getCodigoServicio();
	    }
	    public int solicitarServicioPintura(int dniCliente, int numeroEspecialista, String direccion, double metrosCuadrados, double precioPorMetroCuadrado, int piso, double seguro, double alquilerAndamios) throws RuntimeException {
	        // Verificar si el cliente y el especialista existen
	        if (!clientes.containsKey(dniCliente)) {
	            throw new RuntimeException("El cliente no est� registrado.");
	        }

	        if (!especialistas.containsKey(numeroEspecialista)) {
	            throw new RuntimeException("El n�mero de especialista no est� registrado.");
	        }
	        // Obtener el especialista
	        Especialista especialista = especialistas.get(numeroEspecialista);

	        // Verificar si el especialista se especializa en PinturaEnAltura
	        if (!especialista.getServicioEspecializado().equals("PinturaEnAltura")) {
	            throw new RuntimeException("El especialista no se especializa en PinturaEnAltura.");
	        }

	        // Validar los datos de pintura en altura
	        if (metrosCuadrados <= 0 || precioPorMetroCuadrado <= 0 || piso <= 0 || seguro <= 0 || alquilerAndamios <= 0) {
	            throw new RuntimeException("Los datos de pintura en altura deben ser mayores a 0.");
	        }
	        // Crear el servicio de pintura en altura
	        ServicioPinturaEnAltura servicioPinturaEnAltura = new ServicioPinturaEnAltura(codigoServicioActual, dniCliente, numeroEspecialista, "PinturaEnAltura", direccion, metrosCuadrados, precioPorMetroCuadrado,piso, seguro, alquilerAndamios);
	        servicios.put(codigoServicioActual, servicioPinturaEnAltura);
	        codigoServicioActual++;

	        return servicioPinturaEnAltura.getCodigoServicio();
	    }
	    //SERVICIO GAS REVISION
	    public int solicitarServicioGasistaRevision(int dniCliente, int numeroEspecialista, String direccion, int cantidadArtefactos, double precioPorArtefacto) throws RuntimeException {
	        // Verificar si el cliente y el especialista existen
	        if (!clientes.containsKey(dniCliente)) {
	            throw new RuntimeException("El cliente no est� registrado.");
	        }

	        if (!especialistas.containsKey(numeroEspecialista)) {
	            throw new RuntimeException("El n�mero de especialista no est� registrado.");
	        }

	        // Verificar si el especialista se especializa en gasista revisi�n
	        Especialista especialista = especialistas.get(numeroEspecialista);
	        if (!especialista.getServicioEspecializado().equals("GasistaRevision")) {
	            throw new RuntimeException("El especialista no se especializa en gasista revisi�n.");
	        }

	        // Validar cantidad de artefactos y precio por artefacto
	        if (cantidadArtefactos <= 0 || precioPorArtefacto <= 0) {
	            throw new RuntimeException("La cantidad de artefactos y el precio por artefacto deben ser mayores a 0.");
	        }

	        // Crear el servicio de gasista para revisi�n de artefactos
	        ServicioGasistaRevision servicioGasista = new ServicioGasistaRevision(codigoServicioActual, dniCliente, numeroEspecialista, "GasistaRevision", direccion, cantidadArtefactos, precioPorArtefacto);
	        servicios.put(codigoServicioActual, servicioGasista);
	        codigoServicioActual++;

	        return servicioGasista.getCodigoServicio();
	    }
	    //SERVICIO GAS INSTALACION
	    public int solicitarServicioGasistaInstalacion(int dniCliente, int numeroEspecialista, String direccion, int cantidadArtefactos, double precioPorArtefacto) throws RuntimeException {
	        // Verificar si el cliente y el especialista existen
	        if (!clientes.containsKey(dniCliente)) {
	            throw new RuntimeException("El cliente no est� registrado.");
	        }

	        if (!especialistas.containsKey(numeroEspecialista)) {
	            throw new RuntimeException("El n�mero de especialista no est� registrado.");
	        }

	        // Obtener el especialista
	        Especialista especialista = especialistas.get(numeroEspecialista);

	        // Verificar si el especialista se especializa en GasistaInstalacion
	        if (!especialista.getServicioEspecializado().equals("GasistaInstalacion")) {
	            throw new RuntimeException("El especialista no se especializa en GasistaInstalacion.");
	        }

	        // Validar la cantidad de artefactos y el precio por artefacto
	        if (cantidadArtefactos <= 0 || precioPorArtefacto <= 0) {
	            throw new RuntimeException("La cantidad de artefactos y el precio por artefacto deben ser mayores a 0.");
	        }

	        // Crear el servicio de GasistaInstalacion
	        ServicioGasistaInstalacion servicioGasistaInstalacion = new ServicioGasistaInstalacion(codigoServicioActual, dniCliente, numeroEspecialista, "GasistaInstalacion", direccion, cantidadArtefactos, precioPorArtefacto);
	        servicios.put(codigoServicioActual, servicioGasistaInstalacion);
	        codigoServicioActual++;

	        return servicioGasistaInstalacion.getCodigoServicio();
	    }




	    public double finalizarServicio(int codServicio, double costoMateriales) throws RuntimeException {
	        Servicio servicio = servicios.get(codServicio);

	        if (servicio == null) {
	            throw new RuntimeException("El c�digo de servicio no est� registrado en el sistema.");
	        }

	        if (servicio.isFinalizado()) {
	            throw new RuntimeException("El servicio ya ha sido finalizado.");
	        }

	        // Calcular el costo del trabajo seg�n el tipo de servicio
	        double costoTrabajo = servicio.calcularImporteTotal();

	        // Calcular el precio total a facturar al cliente
	        double precioTotal = costoTrabajo + costoMateriales;

	        // Marcar el servicio como finalizado y guardar el precio total
	        servicio.setFinalizado(true);
	        serviciosFinalizados.put(codServicio, precioTotal);
	        String tipoServicio = servicio.getTipoServicio();
	        facturacionTotalPorTipo.put(tipoServicio, facturacionTotalPorTipo.getOrDefault(tipoServicio, 0.0) + precioTotal);

	        return precioTotal;
	    }

	    public Map<String, Integer> cantidadDeServiciosRealizadosPorTipo() {
	        List<String> tiposServicio = Arrays.asList("Pintura", "PinturaEnAltura", "Electricidad", "GasistaInstalacion", "GasistaRevision");

	        Map<String, Integer> cantidadPorTipo = new HashMap<>();

	        // Inicializar el diccionario con todos los tipos de servicio y valores 0
	        for (String tipoServicio : tiposServicio) {
	            cantidadPorTipo.put(tipoServicio, 0);
	        }

	        // Contar la cantidad de servicios finalizados por tipo
	        for (Servicio servicio : servicios.values()) {
	            if (servicio.isFinalizado()) {
	                String tipoServicio = servicio.getTipoServicio();
	                cantidadPorTipo.put(tipoServicio, cantidadPorTipo.get(tipoServicio) + 1);
	            }
	        }

	        return cantidadPorTipo;
	    }

	    public double facturacionTotalPorTipo(String tipoServicio) {
	        if (!facturacionTotalPorTipo.containsKey(tipoServicio)) {
	            return 0.0; // Si el tipo de servicio no existe, la facturaci�n es 0.
	        }

	        return facturacionTotalPorTipo.get(tipoServicio);
	    }
	    public double facturacionTotal() {
	        double facturacionTotal = 0.0;

	        for (Map.Entry<Integer, Double> entry : serviciosFinalizados.entrySet()) {
	            facturacionTotal += entry.getValue();
	        }

	        return facturacionTotal;
	    }
	    public void cambiarResponsable(int codigoServicio, int nuevoNumeroEspecialista) throws RuntimeException {
	        if (!servicios.containsKey(codigoServicio)) {
	            throw new RuntimeException("El c�digo de servicio no existe.");
	        }

	        if (!especialistas.containsKey(nuevoNumeroEspecialista)) {
	            throw new RuntimeException("El n�mero de especialista no est� registrado.");
	        }

	        Servicio servicio = servicios.get(codigoServicio);
	        String tipoServicioActual = servicio.getTipoServicio();
	        String tipoServicioNuevo = especialistas.get(nuevoNumeroEspecialista).getServicioEspecializado();

	        if (!tipoServicioActual.equals(tipoServicioNuevo)) {
	            throw new RuntimeException("El tipo de servicio del nuevo especialista es diferente al tipo de servicio actual.");
	        }

	        servicio.setNumeroEspecialista(nuevoNumeroEspecialista);
	    }

	    public String listadoServiciosAtendidosPorEspecialista(int numeroEspecialista) {
	        StringBuilder historial = new StringBuilder();
	       

	        for (Servicio servicio : servicios.values()) {
	            if (servicio.getNumeroEspecialista() == numeroEspecialista) {
	                historial.append(" + [ ").append(servicio.getCodigoServicio())
	                        .append(" - ").append(servicio.getTipoServicio())
	                        .append(" ] ").append(servicio.getDireccion()).append("\n");
	            }
	        }

	        return historial.toString();
	    }
	}


