package construcciones3;
class Cliente {
    private int dni;
    private String nombre;
    private String numeroContacto;

    public Cliente(int dni, String nombre, String numeroContacto) {
        this.dni = dni;
        this.nombre = nombre;
        this.numeroContacto = numeroContacto;
    }

    public int getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNumeroContacto() {
        return numeroContacto;
    }
}