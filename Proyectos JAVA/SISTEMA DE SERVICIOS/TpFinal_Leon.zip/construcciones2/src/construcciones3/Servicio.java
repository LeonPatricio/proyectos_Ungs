package construcciones3;
public abstract class Servicio {
    private int codigoServicio;
    private int dniCliente;
    private int numeroEspecialista;
    private String tipoServicio;
    private String direccion;
    private double costoMaterial;
    private int tiempoTrabajado;
    private boolean finalizado;

    public Servicio(int codigoServicio, int dniCliente, int numeroEspecialista, String tipoServicio, String direccion) {
        this.codigoServicio = codigoServicio;
        this.dniCliente = dniCliente;
        this.numeroEspecialista = numeroEspecialista;
        this.tipoServicio = tipoServicio;
        this.direccion = direccion;
        this.costoMaterial = 0;
        this.tiempoTrabajado = 0;
        this.finalizado = false;
    }
    public boolean isFinalizado() {
        return finalizado;
    }

    public void setFinalizado(boolean finalizado) {
        this.finalizado = finalizado;
    }

    public int getCodigoServicio() {
        return codigoServicio;
    }

    public int getDniCliente() {
        return dniCliente;
    }

    public int getNumeroEspecialista() {
        return numeroEspecialista;
    }

    public String getTipoServicio() {
        return tipoServicio;
    }

    public String getDireccion() {
        return direccion;
    }

    public double getCostoMaterial() {
        return costoMaterial;
    }

    public void setCostoMaterial(double costoMaterial) {
        this.costoMaterial = costoMaterial;
    }

    public int getTiempoTrabajado() {
        return tiempoTrabajado;
    }

    public void setTiempoTrabajado(int tiempoTrabajado) {
        this.tiempoTrabajado = tiempoTrabajado;
    }
    public void setNumeroEspecialista(int numeroEspecialista) {
        this.numeroEspecialista = numeroEspecialista;
    }
    public abstract double calcularImporteTotal();
    }