package construcciones3;

class ServicioPintura extends Servicio {
    private double superficie;
    private double costoMetroCuadrado;

    public ServicioPintura(int codigoServicio, int dniCliente, int numeroEspecialista, String tipoServicio, String direccion, double superficie, double costoMetroCuadrado) {
        super(codigoServicio, dniCliente, numeroEspecialista, tipoServicio, direccion);
        this.superficie = superficie;
        this.costoMetroCuadrado = costoMetroCuadrado;
    }
    @Override
    public double calcularImporteTotal() {
        return superficie * costoMetroCuadrado;
    }
}
