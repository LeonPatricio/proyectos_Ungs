package construcciones3;

class ServicioGasistaInstalacion extends Servicio {
    private int cantidadArtefactos;
    private double costoArtefacto;

    public ServicioGasistaInstalacion(int codigoServicio, int dniCliente, int numeroEspecialista, String tipoServicio, String direccion, int cantidadArtefactos, double costoArtefacto) {
        super(codigoServicio, dniCliente, numeroEspecialista, tipoServicio, direccion);
        this.cantidadArtefactos = cantidadArtefactos;
        this.costoArtefacto = costoArtefacto;
    }

    @Override
    public double calcularImporteTotal() {
        return cantidadArtefactos * costoArtefacto;

    }
}