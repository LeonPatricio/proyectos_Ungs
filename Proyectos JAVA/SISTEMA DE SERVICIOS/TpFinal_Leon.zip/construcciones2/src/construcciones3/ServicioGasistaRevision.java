package construcciones3;

class ServicioGasistaRevision extends Servicio {
    private int cantidadArtefactos;
    private double costoArtefacto;

    public ServicioGasistaRevision(int codigoServicio, int dniCliente, int numeroEspecialista, String tipoServicio, String direccion, int cantidadArtefactos, double costoArtefacto) {
        super(codigoServicio, dniCliente, numeroEspecialista, tipoServicio, direccion);
        this.cantidadArtefactos = cantidadArtefactos;
        this.costoArtefacto = costoArtefacto;
    }

    @Override
    public double calcularImporteTotal() {
        double importe;
        if (cantidadArtefactos > 10) {
            importe = cantidadArtefactos * costoArtefacto * 0.85;//15%
        } else if (cantidadArtefactos > 5) {
            importe = cantidadArtefactos * costoArtefacto * 0.9;//10%
        } else {
            importe = cantidadArtefactos * costoArtefacto;
        }
        return importe;
    }
}
