package construcciones3;

class ServicioElectricidad extends Servicio {
    private int horasTrabajo;
    private double valorHora;

    public ServicioElectricidad(int codigoServicio, int dniCliente, int numeroEspecialista, String tipoServicio,
			String direccion, int horasTrabajo, double valorHora) {
		super(codigoServicio, dniCliente, numeroEspecialista, tipoServicio, direccion);
		this.horasTrabajo = horasTrabajo;
		this.valorHora = valorHora;
	}


    public int getHorasTrabajo() {
        return horasTrabajo;
    }

    public double getValorHora() {
        return valorHora;
    }

    @Override
    public double calcularImporteTotal() {
        return horasTrabajo * valorHora;
    }

}
